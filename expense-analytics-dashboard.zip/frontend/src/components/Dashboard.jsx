import axios from "axios";
import { useEffect, useState } from "react";
import { Pie, Bar } from "react-chartjs-2";
import "chart.js/auto";

function Dashboard() {
  const [categoryData, setCategoryData] = useState([]);
  const [monthlyData, setMonthlyData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const categoryRes = await axios.get(
          "http://localhost:5000/api/analytics/category"
        );
        const monthlyRes = await axios.get(
          "http://localhost:5000/api/analytics/monthly"
        );

        setCategoryData(categoryRes.data);
        setMonthlyData(monthlyRes.data);
      } catch (error) {
        console.error("API Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <h3 style={{ textAlign: "center" }}>Loading dashboard...</h3>;
  }

  return (
    <div style={{ width: "80%", margin: "40px auto", textAlign: "center" }}>
      <h2>Expense Analytics Dashboard</h2>

      {/* PIE CHART */}
      {categoryData.length > 0 && (
        <div style={{ height: "350px", marginBottom: "60px" }}>
          <Pie
            data={{
              labels: categoryData.map(item => item._id),
              datasets: [
                {
                  label: "Category-wise Expenses",
                  data: categoryData.map(item => item.total),
                  backgroundColor: [
                    "#FF6384",
                    "#36A2EB",
                    "#FFCE56",
                    "#4CAF50",
                    "#9C27B0"
                  ],
                  borderWidth: 1
                }
              ]
            }}
            options={{ maintainAspectRatio: false }}
          />
        </div>
      )}

      {/* BAR CHART */}
      {monthlyData.length > 0 && (
        <div style={{ height: "350px" }}>
          <Bar
            data={{
              labels: monthlyData.map(item => `Month ${item._id}`),
              datasets: [
                {
                  label: "Monthly Expenses",
                  data: monthlyData.map(item => item.total),
                  backgroundColor: "rgba(54, 162, 235, 0.7)",
                  borderColor: "rgba(54, 162, 235, 1)",
                  borderWidth: 1
                }
              ]
            }}
            options={{ maintainAspectRatio: false }}
          />
        </div>
      )}
    </div>
  );
}

export default Dashboard;
