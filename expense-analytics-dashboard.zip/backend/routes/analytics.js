const router = require("express").Router();
const Expense = require("../models/Expense");

router.get("/category", async (req, res) => {
  const data = await Expense.aggregate([
    { $group: { _id: "$category", total: { $sum: "$amount" } } }
  ]);
  res.json(data);
});

router.get("/monthly", async (req, res) => {
  try {
    const data = await Expense.aggregate([
      {
        $addFields: {
          dateObj: { $toDate: "$date" }
        }
      },
      {
        $group: {
          _id: { $month: "$dateObj" },
          total: { $sum: "$amount" }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json(data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Monthly aggregation failed" });
  }
});


module.exports = router;
